<?php
	error_reporting(0);
	session_start();
	$url_include = $_SERVER['REQUEST_URI'];	$url_include = str_replace('/', '', str_replace('wallet/', '', str_replace('.html', '', str_replace('.php', '', $url_include))));
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?ip=".$_SERVER['REMOTE_ADDR'])));
?>
<!doctype html>
<!--[if lte IE 9]> <html class="lte-ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en"> <!--<![endif]-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/png" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/images/favi.png" sizes="16x16">
    <link rel="icon" type="image/png" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/images/favi.png" sizes="32x32">
    <title>Wallet :: Nanocoin</title>
	<!-- additional styles for plugins -->
    <!-- weather icons -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/weather-icons/css/weather-icons.min.css" media="all">
    <!-- metrics graphics (charts) -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/metrics-graphics/dist/metricsgraphics.css">
    <!-- c3.js (charts) -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/c3js-chart/c3.min.css">
    <!-- uikit -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/uikit/css/uikit.almost-flat.min.css" media="all">
    <!-- flag icons -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/icons/flags/flags.min.css" media="all">
    <!-- altair admin -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/css/main.min.css" media="all">
</head>
<body <?php if(isset($account->notice) == "success"){?>class="sidebar_main_open"<?php }?>>
    <!-- main header -->
	<?php
		include'_components/@header.php';
	?>
    <!-- main header end -->
    <!-- main sidebar -->
	<?php if(isset($account->notice) == "success"){
		include'_components/@sidebar.php';
	}?>
    <!-- main sidebar end -->
    <div id="page_content">
        <div id="page_content_inner">
			<?php $f_exist = '_components/_pages_/'.$url_include.'.php';	if(file_exists($f_exist)){
				include $f_exist;}else{echo '<script>location.href="http://'.$_SERVER['HTTP_HOST'].'/404";</script>';}?>
        </div>
    </div>
    <!-- google web fonts -->
    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
    <!-- momentJS date library -->
    <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/moment/min/moment.min.js"></script>
    <!-- common functions -->
    <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/common.min.js"></script>
    <!-- uikit functions -->
    <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/uikit_custom.min.js"></script>
    <!-- altair common functions/helpers -->
    <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/altair_admin_common.min.js"></script>
	<!-- page specific plugins -->
        <!-- d3 -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/d3/d3.min.js"></script>
        <!-- metrics graphics (charts) -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/metrics-graphics/dist/metricsgraphics.min.js"></script>
        <!-- c3.js (charts) -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/c3js-chart/c3.min.js"></script>
        <!-- maplace (google maps) -->
        <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/maplace.js/src/maplace-0.1.3.js"></script>
        <!-- peity (small charts) -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/peity/jquery.peity.min.js"></script>
        <!-- easy-pie-chart (circular statistics) -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
        <!-- countUp -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/countUp.js/countUp.min.js"></script>
        <!-- handlebars.js -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/handlebars/handlebars.min.js"></script>
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/custom/handlebars_helpers.min.js"></script>
        <!-- CLNDR -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/clndr/src/clndr.js"></script>
        <!-- fitvids -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/fitvids/jquery.fitvids.js"></script>
        <!--  dashbord functions -->
        <script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/pages/dashboard.min.js"></script>
		<!-- datatables -->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
		<!-- datatables colVis-->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/datatables-colvis/js/dataTables.colVis.js"></script>
		<!-- datatables tableTools-->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/datatables-tabletools/js/dataTables.tableTools.js"></script>
		<!-- datatables custom integration -->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/custom/datatables_uikit.min.js"></script>
		<!--  datatables functions -->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/pages/plugins_datatables.min.js"></script>
		<!-- ionrangeslider -->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/ionrangeslider/js/ion.rangeSlider.min.js"></script>
		<!-- htmleditor (codeMirror) -->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/uikit_htmleditor_custom.min.js"></script>
		<!-- inputmask-->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/bower_components/jquery.inputmask/dist/jquery.inputmask.bundle.min.js"></script>
		<!--  forms advanced functions -->
		<script src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wallet/assets/js/pages/forms_advanced.min.js"></script>
		<!-- enable hires images -->
	<script>
        $(function() {
            altair_helpers.retina_images();
        });
    </script>
</body>
</html>
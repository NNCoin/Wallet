<?php
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?ip=".$_SERVER['REMOTE_ADDR'])));
	if($account->notice == "success"){
		header('Location: dashboard');
	}else{
		header('Location: login');
	}
?>
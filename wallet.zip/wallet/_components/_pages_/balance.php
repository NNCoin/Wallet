<?php
if(isset($_SESSION['address_private'])){
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?id=".$_SESSION['id_blockchain'])));
	if($account->notice == "success"){
?>
<h3 class="heading_b uk-margin-bottom">Credit History</h3>

<div class="md-card uk-margin-medium-bottom">
                <div class="md-card-content">
					<?php
						if($account->notice == "success"){
							$user = $account->public_address;
						}
						$deposit = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/transaction?find_from=".$user)));
					?>
					<h3>Debit</h3>
                    <table id="dt_individual_search" class="uk-table" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>To</th>
                            <th>From</th>
                            <th>Value</th>
                            <th>ID</th>
                            <th>Date</th>
                        </tr>
                        </thead>

                        <tfoot>
                        <tr>
                            <th>To</th>
                            <th>From</th>
                            <th>Value</th>
                            <th>ID</th>
                            <th>Date</th>
                        </tr>
                        </tfoot>

                        <tbody>
							<?php $x = 1;
								for($i = 0; $i <= $x; $i++){
									$x++;
									if(isset($deposit[$i]->notice) == "success"){
										echo '<tr><td>'.$deposit[$i]->to.'</td>';
										echo '<td>'.$deposit[$i]->from.'</td>';
										echo '<td>N'.$deposit[$i]->value.'</td>';
										echo '<td>'.$deposit[$i]->id.'</td>';
										echo '<td>'.$deposit[$i]->date.'</td></tr>';
									}elseif(empty($deposit[$i]->notice)){
										$x = $i;
									}
								}
							?>
                        </tbody>
                    </table>
                </div>
</div>
<div class="md-card uk-margin-medium-bottom">
				<div class="md-card-content">
					<?php
						$debit = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/transaction?find_to=".$user)));
					?>
					<h3>Deposit</h3>
                    <table id="dt_default" class="uk-table" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>To</th>
                            <th>From</th>
                            <th>Value</th>
                            <th>ID</th>
                            <th>Date</th>
                        </tr>
                        </thead>

                        <tfoot>
                        <tr>
                            <th>To</th>
                            <th>From</th>
                            <th>Value</th>
                            <th>ID</th>
                            <th>Date</th>
                        </tr>
                        </tfoot>

                        <tbody>
							<?php $x = 1;
								for($i = 0; $i <= $x; $i++){
									$x++;
									if(isset($debit[$i]->notice) == "success"){
										echo '<tr><td>'.$debit[$i]->to.'</td>';
										echo '<td>'.$debit[$i]->from.'</td>';
										echo '<td>N'.$debit[$i]->value.'</td>';
										echo '<td>'.$debit[$i]->id.'</td>';
										echo '<td>'.$debit[$i]->date.'</td></tr>';
									}elseif(empty($debit[$i]->notice)){
										$x = $i;
									}
								}
							?>
                        </tbody>
                    </table>
                </div>
            </div>
<?php }else{
		header('Location: login');
	}
}else{
		header('Location: login');
}
?>
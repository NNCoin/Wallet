<?php
if(isset($_SESSION['address_private'])){
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?id=".$_SESSION['id_blockchain'])));
	if($account->notice == "success"){
?>
<h3 class="heading_b uk-margin-bottom">Dashboard</h3>
            <!-- statistics (small charts) -->
            <div class="uk-grid uk-grid-width-large-1-5 uk-grid-width-medium-1-2 uk-grid-medium uk-sortable sortable-handler hierarchical_show" data-uk-sortable data-uk-grid-margin>
                <div>
                    <div class="md-card" style="height:79px;">
                        <div class="md-card-content">
                            <span class="uk-text-muted uk-text-small">Buy</span>
                            <h5 class="uk-margin-remove">$ <?php
									$usd = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/nanocoin")));
									echo $usd->buy_nnc;
								?><a style="font-size: 10px;"> USD</a></h5>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="md-card" style="height:79px;">
                        <div class="md-card-content">
                            <span class="uk-text-muted uk-text-small">Sell</span>
                            <h5 class="uk-margin-remove">$ <?php
									$usd = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/nanocoin")));
									echo $usd->sell_nnc;
								?><a style="font-size: 10px;"> USD</a></h5>
                        </div>
                    </div>
                </div>
				<div>
                    <div class="md-card" style="height:79px;">
                        <div class="md-card-content">
							<span class="uk-text-muted uk-text-small">Variation</span>
                            <h5 class="uk-margin-remove"><?php
									$usd = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/nanocoin")));
									echo $usd->variation;
								?> %</h5>
                        </div>
                    </div>
                </div>
				<div>
                    <div class="md-card" style="height:79px;">
                        <div class="md-card-content">
							<span class="uk-text-muted uk-text-small">Money Circulating</span>
                            <h5 class="uk-margin-remove">₦ 
								<?php
									$all_nnc = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/status")));
									echo $all_nnc->total_nnc;
								?></h5>
                        </div>
                    </div>
                </div>
				<div>
                    <div class="md-card" style="height:79px;">
                        <div class="md-card-content">
                            <span class="uk-text-muted uk-text-small">Blocks Mined</span>
                            <h5 class="uk-margin-remove">
								<?php
									$blocks = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/status")));
									echo $blocks->blocks_mined;
								?>
							</h5>
                        </div>
                    </div>
                </div>
            </div>

<div class="uk-grid uk-margin-medium-bottom" data-uk-grid-margin>
                <div class="uk-width-medium-2-3">
                    <div class="md-card">
                        <div class="md-card-content">
                            <ul class="uk-tab uk-tab-grid" data-uk-tab="{connect:'#tabs_4'}">
                                <li class="uk-width-1-3 uk-active"><a href="#">Facebook</a></li>
                                <li class="uk-width-1-3"><a href="#">Calculator NNC</a></li>
                                <li class="uk-width-1-3"><a href="#">Calculator USD</a></li>
                            </ul>
                            <ul id="tabs_4" class="uk-switcher uk-margin">
                                <li>
									<div>
										<center>
											<script>(function(d, s, id) {
												var js, fjs = d.getElementsByTagName(s)[0];
												if (d.getElementById(id)) return;
												js = d.createElement(s); js.id = id;
												js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=185373328176597";
												fjs.parentNode.insertBefore(js, fjs);
												}(document, 'script', 'facebook-jssdk'));
											</script>
											<div class="fb-page" data-href="https://www.facebook.com/Nanocoin" data-tabs="timeline" data-height="500" width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
										</center>
									</div>
								</li>
                                <li>
<script>
function calcula(operacao){
var parcela1 = document.calc.parcela1.value
var parcela2 = document.calc.parcela2.value
var result = eval(parcela1 + operacao + parcela2)
document.calc.resultado.value = parseFloat(result.toFixed(2));
}
</script>
<form name="calc"><br>
<?php
	$usd = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/nanocoin")));
?>
<div class="uk-form-row">
	<label for="masked_currency">₦ AMOUNT</label>
	<input name="parcela1" class="md-input masked_input" id="masked_currency" type="text" data-inputmask="'alias': 'numeric', 'groupSeparator': '', 'autoGroup': true, 'digits': 9, 'digitsOptional': false" data-inputmask-showmaskonhover="false" value="1.000000000">
</div>
<input name="parcela2" type="Hidden" value="<?php echo $usd->buy_nnc;?>" /><br>
<div class="uk-form-row">
	<label for="masked_currency">$ VALUE</label>
	<input name="resultado" class="md-input masked_input" id="masked_currency" type="text" data-inputmask="'alias': 'numeric', 'groupSeparator': '', 'autoGroup': true, 'digits': 2, 'digitsOptional': false" data-inputmask-showmaskonhover="false" value="<?php echo $usd->buy_nnc;?>" />
</div><br><br>
<input class="md-btn md-btn-primary" onclick="calcula('*')" type="Button" value="Calculate" />
</form>
								</li>
								<li>
<script>
function calcula2(operacao2){
var parcela12 = document.calc2.parcela12.value
var parcela22 = document.calc2.parcela22.value
var result2 = eval(parcela12 + operacao2 + parcela22)
document.calc2.resultado2.value = parseFloat(result2.toFixed(9));
}
</script>
<form name="calc2"><br>
<?php
	$nnc = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/nanocoin")));
?>
<div class="uk-form-row">
	<label for="masked_currency">$ AMOUNT</label>
	<input name="parcela12" class="md-input masked_input" id="masked_currency" type="text" data-inputmask="'alias': 'numeric', 'groupSeparator': '', 'autoGroup': true, 'digits': 2, 'digitsOptional': false" data-inputmask-showmaskonhover="false" value="1.00">
</div>
<input name="parcela22" type="Hidden" value="<?php echo $nnc->buy_usd;?>" /><br>
<div class="uk-form-row">
	<label for="masked_currency">₦ VALUE</label>
	<input name="resultado2" class="md-input masked_input" id="masked_currency" type="text" data-inputmask="'alias': 'numeric', 'groupSeparator': '', 'autoGroup': true, 'digits': 9, 'digitsOptional': false" data-inputmask-showmaskonhover="false" value="<?php echo $nnc->buy_usd;?>" />
</div><br><br>
<input class="md-btn md-btn-primary" onclick="calcula2('*')" type="Button" value="Calculate" />
</form>
								</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="uk-width-medium-1-3">
                    <div>
						<div class="md-card md-card-hover md-card-overlay">
							<div class="md-card-content" style="height: 240px;">
								<center><b>PUBLIC ADDRESS</b><br><img src="https://chart.googleapis.com/chart?cht=qr&chs=180x180&choe=UTF-8&chld=H|2&chl=<?php echo $account->public_address;?>" width="180px" height="180px"/><b><?php echo $account->public_address;?></b></center>
							</div>
							<div class="md-card-overlay-content">
								<div class="uk-clearfix md-card-overlay-header">
									<i class="md-icon material-icons md-card-overlay-toggler uk-text-primary">&#xE0DA;</i>
									<h3>
										  <center>To see PRIVATE ADDRESS</center>
									</h3>
								</div>
								<p class="truncate-text"><center><img src="https://chart.googleapis.com/chart?cht=qr&chs=180x180&choe=UTF-8&chld=H|2&chl=<?php echo $account->address_private;?>" width="180px" height="180px"/><a style="font-size: 8px;text-decoration: none;color: black;"><?php echo $account->address_private;?></a></center></p>
							</div>
						</div>
					</div>
                </div>
            </div>
<?php }else{
		header('Location: login');
	}
}else{
		header('Location: login');
}
?>
<?php
if(isset($_SESSION['address_private'])){
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?id=".$_SESSION['id_blockchain'])));
	if($account->notice == "success"){
?>
<h3 class="heading_b uk-margin-bottom">Transfer</h3>

<div class="md-card">
                <div class="md-card-content">
					<center><?php
						if(isset($_POST['send'])){
							if(isset($_POST['amount_form']) and isset($_POST['to_form'])){
								$amount_f = $_POST['amount_form'];
								$to_f = $_POST['to_form'];
							}else{
								$amount_f = null;
								$to_f = null;
							}
							$trans = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/transaction/send?id=".$_SESSION['id_blockchain']."&value=".$_POST['amount_form']."&to=".$_POST['to_form'])));
							if($trans->notice == "success"){
								echo '<div class="uk-alert uk-alert-success" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>'.$trans->message.'</div><br>';
							}else{
								echo '<div class="uk-alert uk-alert-danger" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>'.$trans->message.'</div><br>';
							}
						}
					?>
			<div class="uk-grid" data-uk-grid-margin>
				<div class="uk-width-medium-1-5"></div>
                <div class="uk-width-medium-3-5">
                    <form action="#" method="post">
						<table cellspacing="10">
							<tr>
								<div class="uk-form-row">
									<label for="masked_currency">AMOUNT</label>
									<input name="amount_form" class="md-input masked_input" id="masked_currency" type="text" data-inputmask="'alias': 'numeric', 'groupSeparator': '', 'autoGroup': true, 'digits': 9, 'digitsOptional': false" data-inputmask-showmaskonhover="false" placeholder="1.000000000" required>
								</div>
							</tr>
							<tr>
								<div class="uk-form-row">
									<label>TO</label>
									<input type="text" name="to_form" id="input_counter" maxlength="22" class="input-count md-input" placeholder="PUBLIC ADDRESS" required>
								</div>
							</tr>
						</table>
						<br />
						<input class="md-btn md-btn-primary" type="submit" value="Submit" name="send">
					</form></div></div></center>
                </div>
            </div>
<?php }else{
		header('Location: login');
	}
}else{
		header('Location: login');
}
?>
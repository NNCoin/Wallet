<?php
if(isset($_SESSION['address_private'])){
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?id=".$_SESSION['id_blockchain'])));
	if($account->notice == "success"){
      	echo '<meta http-equiv="refresh" content="0;url=/wallet/dashboard">';
		$logout = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account/logout?id=".$_SESSION['id_blockchain'])));
	}
}
?>
<div class="md-card">
                <div class="md-card-content">
				<center><img src="assets/images/logotipo.png" width="200px"></center><br>
			<div class="uk-grid" data-uk-grid-margin>
				<div class="uk-width-medium-1-5"></div>
                <div class="uk-width-medium-3-5">
				<?php
						if(isset($_POST['login'])){
							if(isset($_POST['pv_add_form']) and isset($_POST['gauth_pin_form'])){
								$lgin = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account/logon?private_address=".$_POST['pv_add_form']."&pin=".$_POST['gauth_pin_form'])));
								if($lgin->notice == "error"){
									echo '<div class="uk-alert uk-alert-danger" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>'.$lgin->message.'</div><br>';
								}
								if($lgin->notice == "success"){
                                  	$_SESSION['id_blockchain'] = $lgin->security_id;
                                    $_SESSION['address_private'] = $_POST['pv_add_form'];
									echo '<div class="uk-alert uk-alert-success" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>'.$lgin->message.'</div><br>';
									echo '<meta http-equiv="refresh" content="2;url=/wallet/dashboard">';
								}
							}
						}
						if(isset($_POST['register'])){
							$reg = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account/create")));
							echo '<div class="uk-alert uk-alert-success" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>Account successfully created</div>';
							echo '<div class="uk-alert uk-alert-warning" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>'.$reg->message.'</div>';
							echo '<div class="uk-alert uk-alert-large" data-uk-alert>Private Address: '.$reg->private_address.'<br><center><img src="'.$reg->qr_url.'" /></center></div>';
							echo '<div class="uk-alert uk-alert-warning" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>'.$reg->warning.'</div><br>';
						}
					?>
					<form action="#" method="post">
						<table cellspacing="10">
							<tr>
								<div class="uk-form-row">
									<label>PRIVATE ADDRESS</label>
									<center><input type="text" name="pv_add_form" id="input_counter" maxlength="60" class="input-count md-input" placeholder="PRIVATE ADDRESS"></center>
								</div>
							</tr>
							<tr>
								<div class="uk-form-row">
									<label>PIN (Google Authenticator)</label>
									<center><input type="text" name="gauth_pin_form" id="input_counter" maxlength="6" class="input-count md-input" placeholder="000000"></center>
								</div>
							</tr>
						</table>
						<center><input class="md-btn md-btn-primary" type="submit" value="Login" name="login">
						<input class="md-btn md-btn-primary" type="submit" value="Register" name="register"></center>
					</form>
                </div></div>
                </div>
            </div>
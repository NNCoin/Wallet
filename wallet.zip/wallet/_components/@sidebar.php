<?php
if(isset($_SESSION['address_private'])){
	$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?id=".$_SESSION['id_blockchain'])));
	if($account->notice == "success"){
?>
    <aside id="sidebar_main">
        <a href="#" class="uk-close sidebar_main_close_button"></a>
        <div class="sidebar_main_header">
			<div class="sidebar_logo">
				<center>
					<a href="/wallet/dashboard" style="margin-left: 0px;">
						<img src="assets/images/logotipo.png" width="125" class="">
					</a>
				</center>
			</div>
        </div>
        <div class="menu_section">
            <ul>
                <li <?php if($url_include == 'dashboard'){echo'class="act_section"';}?>>
                    <a href="/wallet/dashboard">
                        <span class="menu_icon uk-icon-dashboard"></span>
                        Dashboard
                    </a>
                </li>
				<li <?php if($url_include == 'balance'){echo'class="act_section"';}?>>
					<a href="/wallet/balance">
						<span class="menu_icon uk-icon-credit-card"></span>
						Credit History
					</a>
				</li>
				<li <?php if($url_include == 'transfer'){echo'class="act_section"';}?>>
					<a href="/wallet/transfer">
						<span class="menu_icon uk-icon-upload"></span>
						Transfer
					</a>
				</li>
				<li <?php if($url_include == 'deposit'){echo'class="act_section"';}?>>
					<a href="/wallet/deposit">
						<span class="menu_icon uk-icon-download"></span>
						Deposit
					</a>
				</li>
				<li>
					<a href="http://nanocoin-global.com/stores" target="_blank">
						<span class="menu_icon uk-icon-shopping-cart"></span>
						Shops
					</a>
				</li>
				<li>
					<a href="http://nanocoin-global.com/forums/forum/documentation/" target="_blank">
						<span class="menu_icon uk-icon-code"></span>
						API
					</a>
				</li>
            </ul>
        </div>
    </aside>
<?php }}?>
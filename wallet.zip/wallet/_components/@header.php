<header id="header_main">
        <div class="header_main_content">
			<?php
			if(isset($_SESSION['address_private'])){
				$account = json_decode(base64_decode(file_get_contents("http://nanocoin-global.com/blockchain/account?id=".$_SESSION['id_blockchain'])));
				if($account->notice == "success"){
			?>
            <nav class="uk-navbar">
                <!-- main sidebar switch -->
                <a href="#" id="sidebar_main_toggle" class="sSwitch sSwitch_left">
                    <span class="sSwitchIcon"></span>
                </a>
                <!-- secondary sidebar switch -->
                <div class="uk-navbar-flip">
                    <ul class="uk-navbar-nav user_actions">
						<li>
                            <a href="/wallet/balance" class="user_action_image"><span class="uk-badge" style="font-size:20px; padding:5px 6px;"><b>₦</b> 
								<?php
									echo number_format(floatval($account->credit), 9, '.', '');
								?>
								</span><i class="material-icons md-36 md-light">account_balance_wallet</i></a>
                        </li>
                        <li>
                            <a href="/wallet/login" class="user_action_image"><i class="material-icons md-36 md-light">&#xE8AC;</i></a>
                        </li>
                    </ul>
                </div>
            </nav>
          <?php }}?>
        </div>
    </header>